# ngTable ES6+Webpack Demo App

## Overview

* Loads `ng-table` on to the page using webpack
* Application code written in ES2015 and transpiled to ECMAScript 5

## Running sample App

1. If you haven't already done so: `npm run setup`
2. `demo-apps/es6-webpack` (this directory)
3. `npm start`
    * runs `webpack-dev-server` to serve this app's index.html