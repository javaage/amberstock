declare module '@types/angular-route' {
    import mod = angular.route;
    export = mod;
}