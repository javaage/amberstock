/// <reference types="angular-mocks" />
/// <reference types="angular" />
/// <reference types="jasmine" />
/// <reference types="karma-jasmine" />
/// <reference types="lodash" />
/// <reference types="node" />


/* Note
 this file should not be necessary but karma / webpack does not seem resolve types
 declarations without the help in the form of tripple dash references
 */
