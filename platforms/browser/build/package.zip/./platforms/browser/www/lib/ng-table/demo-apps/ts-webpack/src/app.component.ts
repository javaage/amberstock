import { IComponentOptions } from 'angular';

export class AppComponent implements IComponentOptions {
    templateUrl = './app.component.html'
}